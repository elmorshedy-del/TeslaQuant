# Tesla research infrastructure — first release

## Built

The approved architecture is implemented as a Python project with a Streamlit app, an independent persistent worker, a SQLite ledger and immutable Parquet snapshots queried with DuckDB. The original research blueprint is included unchanged in the source package.

| Part | Status |
|---|---|
| Episodes / Data, Experiments, Evidence, Current Forecast views | Implemented and tested |
| Versioned data, provenance, availability clocks, checksum verification | Implemented |
| Durable jobs, deduplication, lease fencing, retries and failed-job isolation | Implemented and tested |
| Import of the prior Tesla audit | Completed using real supplied data |
| Daily provider ingestion | Adapter tested with paginated controlled responses; actual account download pending keys |
| Price-only review registry | Implemented; real complete-history outcome review remains unfinished |
| Frozen daily benchmark | Implemented with chronological validation, confirmation purging, probability scores, calibration bins and onset/false-alert reporting |
| Gamma, flow, option-chain and calendar-event layers | Storage contracts ready; richer measurement/feature pipelines remain the next research stage |
| Local backups and restoration | Implemented and tested, including concurrency, tampering and simulated remote outage |
| DigitalOcean Spaces | Integration ready; real connectivity needs credentials and a bucket |
| Docker Compose and authenticated Caddy configuration | Prepared and structurally checked; actual container/remote HTTPS verification pending |
| Microsoft autonomous research tools | Deferred until evaluator and research protocol are frozen |
| Live Tesla probability | Blocked until a prospectively eligible frozen model exists |

## Existing data loaded

- Equity: 2,936 TSLA/SPY records covering 1,468 session observations per symbol.
- Gamma: 1,395 in-calendar records; one off-calendar source row excluded.
- Three spot discrepancies quarantined; 436 earlier rows flagged for an unverified price basis; 956 retained as retrospective proxy observations.
- All nine supplied reference weeks preserved as unconfirmed week identifiers.
- Historical availability limitations and September 2026 gamma-series revision provenance retained.
- No unreviewed date was converted into a negative outcome. No real model was fitted or promoted.

## Verification

36 automated tests pass. They include concurrent job claims, stale-worker rejection, deterministic versioning, provider pagination, calendar gaps, future availability, review completeness, full confirmation-window purging, four-view app reopening, a full synthetic experiment and consistent backup restoration.

The synthetic experiment proves pipeline behavior only. It does not establish market predictive performance.

All four views also rendered successfully with the imported real audit. An actual locally started app returned HTTP status 200 from its health endpoint. The package has pinned dependencies, source-version hashes in reports, deployment instructions and a verified starting-data snapshot.

One independent read-only code review found no Critical issues and identified backup/review-contract defects. Regression tests reproduced each accepted finding before the fixes; the full suite then passed. Date normalization, malformed review input and missing declared archive checksum members were also repaired because they affect trustworthy results or provided app flows. No review findings were silently dropped.

## Deployment limit and decisions

The connected DigitalOcean account was inspected read-only. Its existing 1 GB server was left unchanged. This execution workspace cannot reach that server over SSH: the transport check returned network-unreachable. It also has no Docker daemon. Therefore no paid server was created, no public app URL is claimed, and container builds/remote authentication are not presented as verified.

The release remains portable to the approved dedicated DigitalOcean server. The deployment script rejects public mode without a hostname and password hash; local access binds loopback. Provider credentials are isolated from the app and excluded from the package.

Full decisions and test history are in `docs/implementation-ledger.md`. Local project history is included as a Git bundle; no external repository has been created or modified.

## Next concrete work

Deploy this release from an environment with access to the server, then finish the price-only outcome rubric and complete-history review. With daily history and reviewed outcomes pinned, run the benchmark, add the registered demand–absorption–gamma measurements, and compare them through the same evaluator.
