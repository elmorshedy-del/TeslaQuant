# Tesla Research Lab — infrastructure 0.1

A private research app for asking whether Tesla's recent demand, absorption and feedback conditions help anticipate new explosive upside episodes. The design and original theory are preserved in `docs/research-blueprint.md`.

## What works in this release
- Four research views: Episodes / Data, Experiments, Evidence, Current Forecast.
- Immutable, checksum-verified Parquet snapshots, analytical DuckDB queries and a durable SQLite ledger.
- A separate leased worker, deduplicated submissions, retries, failed-job isolation and restart recovery.
- Import of the existing audit with provenance, unknown publication clocks, gamma quarantine, split-basis flags and unconfirmed reference weeks retained.
- Alpaca consolidated daily ingestion adapter with pagination and original response retention. Account keys are needed for an actual provider download.
- Append-only price-only annotation snapshots and complete-review coverage; unreviewed dates cannot become negative labels.
- A fixed logistic benchmark with eight prior-session predictors, three-year initial training, six-month outer tests, purged labels, chronological inner selection, train-only scaling and validation-selected alert thresholds.
- Probability scores, held-out calibration bins, onset detection, false alerts, lead times and a saved trial/configuration/source-version ledger.
- Consistent backups with verified restoration and optional Spaces upload verification.
- Docker Compose/Caddy deployment configuration with loopback-only local access and authenticated public HTTPS.

The numerical full-pipeline test uses synthetic labels, which establish software behavior only. There is no validated market model, approved live forecast, complete real event census, uncertainty bootstrap, gamma/flow feature experiment, Microsoft autonomous agent, or actual ThetaData connection in this release. Gamma, flow, option-chain and calendar-event storage contracts are implemented; richer feature families are the next research stages.

## Local start (Python 3.12)

```bash
python3 -m venv .venv
.venv/bin/pip install --require-hashes -r requirements.lock
.venv/bin/pip install --no-deps -e .
.venv/bin/tesla-lab init
.venv/bin/tesla-lab worker
```

Keep the worker running. In a second terminal:

```bash
.venv/bin/streamlit run app.py --server.address=127.0.0.1
```

Open `http://localhost:8501`. The app queues jobs; closing the browser does not stop the worker. The default data folder is `var`; set `TESLA_DATA_DIR` for another location. Initial UI operation is self-service, but completing price-only research annotation remains substantive research work.

The release archive includes `bootstrap/tesla-state.tar.gz`, a verified starting snapshot containing the imported real audit and nine unconfirmed reference weeks. To load it into a fresh local checkout, run `.venv/bin/tesla-lab restore bootstrap/tesla-state.tar.gz var` before `init` or starting either process. Do not restore over an existing data folder. It contains no reviewed-negative census, trained model or synthetic research report.

Queue the supplied audit with `tesla-lab import-audit /path/to/Tesla_Model_Audit_2026-10-07.zip`, or use the upload control. Configure provider keys in the worker environment, then request daily history in the app. New daily downloads create a new version, not an in-place append. Pin one complete version in each experiment.

## DigitalOcean deployment

The approved initial target is a dedicated Ubuntu server with 4 CPUs and 8 GB memory. Existing small servers running other projects should not be repurposed. This release includes deployment files; server provisioning and remote container verification are separate from local tests.

1. Put this folder on the server and install Docker Engine with the Compose plugin using the official Ubuntu guide: https://docs.docker.com/engine/install/ubuntu/ .
2. Copy `.env.example` to `.env`, set provider keys if needed, and restrict permissions with `chmod 600 .env`.
3. For local/private tunnel access run `bash deploy/setup.sh local`; the only app port is bound to loopback.
4. For public access, point a DNS hostname to the server. Generate a password hash interactively with `docker run --rm -it caddy:2.10.2-alpine caddy hash-password`. Save the hash in `.env` inside single quotes as `LAB_PASSWORD_HASH='$2a$...'`, set `LAB_DOMAIN` and `LAB_USERNAME`, then run `bash deploy/setup.sh public`.
5. Allow HTTPS/HTTP and required administrator SSH access in the cloud firewall; port 8501 stays private. Open `https://your-hostname` and sign in. Verify an unauthenticated request is rejected before declaring public access ready.

No secrets belong in git, archive releases, screenshots, saved experiment configurations or browser forms. App receives no vendor keys; only worker receives Alpaca keys, and only backup receives Spaces keys. There is no Docker socket mount.

Services restart automatically. A crashed running job is reclaimed after its 180-second lease expires, at most three attempts. Computation may restart at the stage boundary; in-memory computation is not magically resumed. All referenced dataset/report objects are immutable. The SQLite manifest and durable Docker volume preserve jobs across container replacement.

## Backup and restore

```bash
tesla-lab backup /safe/location/snapshot.tar.gz
tesla-lab restore /safe/location/snapshot.tar.gz /new/empty/data
```

The backup scheduler keeps seven local daily snapshots, including during a remote-storage outage. It retries the same pending upload with a five-minute delay increasing to at most one hour; a new daily snapshot becomes the latest pending upload. Configure Spaces endpoint/bucket/keys for off-server copies; it downloads the uploaded object to verify its hash. Cloud upload is untested until credentials are supplied. Backups include only objects referenced by the exact database snapshot, excluding concurrent staging files. Restore requires an empty target and validates all members and checksums before replacing it. After a restore, jobs already marked running become eligible for recovery after their original lease expires. Keep independent off-server copies; local snapshots alone do not survive loss of a server.

## Reproduction and research gates

Run `.venv/bin/python -m pytest -q`. Tests cover real local components and fake network responses only at the provider boundary. Review exact clock/label/data definitions in the spec and review-format documents. Report configuration, data, annotation and runtime versions are saved; repeated evaluation of a pinned configuration is deterministic in the same runtime.

The current forecast page intentionally reports a blocked state until a frozen, prospectively eligible model and live input checks exist. Do not convert retrospective experiments into trading recommendations. The selected simple benchmark is a starting control; the full blueprint's competing learners, richer matched-date ablations, uncertainty and prospective ledger gates remain research work.

## Next implementation stages

First finalize the price-only onset rubric and review complete history. Then fill the daily provider/market/calendar coverage, reproduce the benchmark, and add the registered demand–absorption–gamma feature tests. Microsoft RD-Agent follows a fixed evaluator with restricted data/code access; it does not define the outcome or silently revise the holdout.
