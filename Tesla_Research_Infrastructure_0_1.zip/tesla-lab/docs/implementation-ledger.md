# Implementation ledger — plan: docs/superpowers/plans/2026-10-08-foundation.md

Scope: approved architecture, implementation requested directly by Ahmed. Native inline execution selected by task context.
Pre-flight: tasks 1–4 consume Ledger/Lake and pinned immutable version IDs consistently; data/report bodies stay out of SQLite.
Ruling: use a new isolated local git project on build/infrastructure — no existing application/repository is present. Preserve a portable release archive until an external repository is connected.
Ruling: build and verify before paid provisioning — existing 1 GB server may run unrelated projects and cannot be safely repurposed.

Task 1: complete — 8 tests passed; SQLite reserved-keyword initialization defect corrected and covered.
Task 2: initial verification — 14/15 passed; fixture used 2025-01-09, an actual exchange closure. Corrected fixture to 2025-01-08; the exchange calendar correctly rejected the assumed session. Await full green run before marking complete.
Task 2: complete — corrected calendar fixture; all 15 foundation/ingestion tests passed.
Task 3: complete — full 21-test suite passed, including synthetic deterministic chronological report, data gaps, availability cutoff, purging and four-view app recovery.
Task 4: initial verification — 25 tests passed, including new public-launch guard, tamper rejection, forecast immutability and fresh operational worker checks. Docker daemon is unavailable here; container build and remote HTTPS verification are not claimed.
Final review: one independent read-only reviewer; no Critical findings, three Important backup/review-contract findings and three initially Minor input issues.
Final: Ruling: re-grade non-normalized dates, malformed review roots and silently skipped declared checksum members as Important — they can respectively corrupt event counts, crash a provided UI flow or misrepresent archive integrity; repair them in the same contract-focused fix pass.
Final: fixed concurrent staging-file backup race — test_backup_ignores_concurrent_uncommitted_staging_object failed with FileNotFoundError before fix; backup now uses the exact SQLite snapshot's committed references.
Final: fixed remote-backup outage/restart disk growth — test_spaces_failure_retries_same_snapshot_and_retains_only_seven RED→GREEN; same snapshot retried with bounded backoff and local retention enforced regardless of remote availability.
Final: fixed undeclared/fractional/boolean confirmation lag — six parameterized persistence tests RED→GREEN; explicit integer required, including explicit zero.
Final: fixed date normalization, malformed review roots and missing declared checksum entries — dedicated regressions RED→GREEN.
Final: Ruling: remote server provisioning deferred because SSH transport returns ENETUNREACH from this workspace — a newly billed server could not be configured here; preserve tested code and avoid an empty paid resource.
Final: Ruling: Docker configuration structurally checked only — no Docker daemon exists in this workspace; container-build and public-HTTPS behavior remain explicit deployment gates.
Final: Ruling: predictive validity, richer gamma/flow features, uncertainty intervals and live promotion are not release acceptance claims — they remain the approved blueprint's next research stages.
Final: fixed report reproducibility/calibration omissions — source-version and calibration count assertions RED→GREEN; full suite 36/36 passed.
Task 4: complete for portable infrastructure release — tests, actual local HTTP health, real-data UI checks and deployment structural checks recorded; remote deployment remains blocked by network access.
