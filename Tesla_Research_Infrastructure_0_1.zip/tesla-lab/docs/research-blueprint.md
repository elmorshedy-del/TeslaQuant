# Predicting Tesla explosion episodes — independent research blueprint

7 October 2026 • Version 1.1 • Revised theory, measurements and tests; no deployment or new fitted model

**The objective is to predict explosive Tesla upside episodes like the dated examples supplied by Ahmed, early enough to be useful and with a measured false-alert burden.** The demand–absorption–feedback hypothesis is a leading, explicitly planned research study. It links persistent core demand, options-induced demand, changing market resistance and reinforcing or opposing reactions. Gamma hedging and institutional execution cycles are retained as specific mechanisms to test. Their contribution must be established against alternatives; the objective is not to prove the theory correct.

**My recommendation:** Develop a price-only event dataset and a simple predictive benchmark, while translating the demand–absorption–feedback theory into measurable, falsifiable hypotheses. Run the theory study and a restrained empirical comparison through the same chronological evaluator. Build a private Python research app on one DigitalOcean server, using Streamlit for the interface and a separate persistent worker for computation. Add Microsoft RD-Agent only after the experiment rules are fixed. Google Co-Scientist, Qlib and Floot are optional tools, not dependencies of the first release.

**Revision 1.1:** The theoretical work now has dedicated hypotheses, measurement definitions, mechanism checks and gamma-specific comparisons. The unified order-flow paper is an explicit theoretical anchor; institutional execution persistence is distinguished from calendar-related flows, and dealer gamma is distinguished from a vendor GEX proxy. The Streamlit/Python/DigitalOcean architecture from version 1.0 remains the implementation recommendation.

The design is stable for the first research cycle. Its outcome is not predetermined: we may find useful predictors, only broad susceptibility, or insufficient predictive information.

**1. What I reviewed and what the audit changes**

Reviewed: the conversation, `TSLA_GEX_Explosion_Model_Handoff.md`, the later `Tesla_Model_Audit_2026-10-07.zip` including its audit report, the separate `Tesla_Research_Review_and_Test_Plan.md`, and current primary documentation listed below. The earlier audit was read, not rerun here. It contains actual exploratory data work, but there is still no validated explosion predictor.

The original handoff supplies these reference episodes:

| Episode | Supplied onset-week identifier | Supplied continuation week |
|---|---|---|
| Summer 2024 | 24 June 2024 | 1 July 2024 |
| October 2024 | 21 October 2024 | — |
| November 2024 | 4 November 2024 | — |
| December 2024 | 2 December 2024 | 9 December 2024 |
| May 2025 | 12 May 2025 | — |
| September 2025 | 1 September 2025 | 8 September 2025 |

These are nine labeled weeks but six episodes under the current grouping. They are week identifiers, not yet independently established daily onset dates. September 1, 2025 was a market holiday; the actual session calendar matters. Preserve the original annotations. If a consistent rubric classifies some examples differently, record the discrepancy instead of moving dates to favor a model. Test sensitivity to grouping closely spaced October/November episodes.

The audit's consequential findings:

- Missing options rows and stale underlying prices distorted some price windows. It corrected the pre-September 2025 20-session return from about 4.1% to 10.32%; the old first-week/second-week momentum story therefore needs retesting.
- It identified 73 missing gamma sessions, including the summer 2024 block, and quarantined suspect observations.
- The public GEX series was rebuilt in September 2026. The publisher confirms historical replacement and a calls-positive/puts-negative model convention. That history does not establish what a trader could have observed each day, or actual dealer inventory. [1]
- One concrete rule caught two of four covered onsets and triggered in 27 of 137 unreviewed comparison weeks. Those 27 are a review queue, not established false positives: the original positive examples were not an exhaustive event census.
- The original 216-specification findings, significance claims and earlier model scores were not reproduced by the later audit. Keep them as claims to reproduce, not accepted evidence.

The biggest unresolved issue is not which ML package to install. It is whether the intended outcome is defined consistently across all history, and whether any observable information distinguishes its onset from similar situations that do not explode.

**2. Exact research question and outputs**

> Before a trading session begins, what is the probability that Tesla will begin a new explosive upside episode within the next ten trading sessions, of the kind represented by the supplied historical examples? Can a model improve that forecast over simple price, volatility, market and calendar information while producing few enough false alerts to be useful?

Ten sessions is the primary warning horizon. Five sessions is a prespecified secondary timing test. The choice expresses the intended decision window; it is not a discovered natural market constant. Twenty-session returns can provide context, but twenty sessions is not another main event target in the first cycle.

The continuation question is separate:

> When an upward episode is already visibly underway, what predicts further acceleration rather than a stall or reversal?

Do not count correctly identifying the second week of an obvious rally as predicting its original onset. Develop the onset model first; a continuation model needs its own sufficient sample and online eligibility rule.

The final app should eventually show:

1. Probability of a new episode within ten sessions, compared with the relevant historical baseline.
2. Whether the current alert threshold is crossed, with its tested alert frequency and precision.
3. The input timestamp, data quality and strength of evidence supporting the estimate.
4. Which measured conditions influence the model, stated as associations.
5. Supporting upside/downside scenarios if separately validated.

Until probabilities are calibrated on enough held-out cases, show an experimental score or insufficient evidence. A percentile rank is not a probability.

**3. Define the outcome before choosing its predictors**

The supplied dates are reference examples for the concept. Six selected episodes cannot by themselves establish which features work or support a flexible probability model.

The event-definition study comes first:

1. Obtain a clean TSLA price/volume history, initially targeting 2016 onward. Construct the complete trading-session calendar before any options joins.
2. Examine each supplied episode's price path. Record what marks the change: speed of upward displacement, size relative to prior volatility, persistence, and acceleration relative to the preceding trend. Separate a sudden upward gap, a sustained multi-session run, continuation, and bottoming reversal.
3. Write a price-only annotation rubric with examples and counterexamples. Hide all GEX, flow, model scores and explanatory headlines during outcome labeling. This prevents the outcome being defined to flatter a preferred explanation.
4. Apply the rubric to the complete eligible history, including quiet weeks, other rallies, selloffs and apparent buildups that fail. Use a second independent blinded review of uncertain cases and a sample of accepted/rejected cases; retain disagreement rather than forcing certainty.
5. Produce an episode registry with first onset session, end, continuation segments, category, confidence and reason. Preserve uncertain boundaries and evaluate sensitivity to them.
6. Freeze the registry/rubric before evaluating candidate predictors. The known episodes remain discovery examples; agreement with them alone is not validation.

The conceptual definition is **a marked acceleration into unusually large, sustained upward displacement relative to Tesla's preceding behavior**. It does not require low GEX, buying pressure, a particular catalyst or a quiet starting state. April-style bottoming reversals get their own category, respecting the earlier distinction from the grind-to-explosion template.

The annotation rubric must become operational: the first data milestone will fix the lookback, permitted onset ambiguity, forward confirmation window, treatment of gaps and episode grouping. Those details cannot honestly be certified from prose alone without inspecting the cleaned example paths. This is a defined research deliverable, not a request for the user to invent thresholds.

Alongside the annotations, create a price-only quantitative definition using normalized upward displacement, directional persistence and acceleration. Choose its small parameter set on development price paths without examining predictor performance; freeze it; report sensitivity to nearby definitions. An unsupervised state model is an optional label-sensitivity tool, not ground truth. Agreement across reasonable definitions is stronger evidence than one hand-tuned definition.

Do not equate “explosion” with one convenient +20% threshold. Store continuous path outcomes as a check against label fragility. If reliable event labels cannot be produced, the study must report that limitation rather than quietly replace the main objective with generic volatility forecasting.

**4. The observation, forecast clock and label**

One forecast is issued at 09:00 America/New_York each trading day. Initial numerical features use completed regular sessions through the previous session, subject to actual publication availability. Known-event calendar information must also have been public by the cutoff. Premarket prices and unscheduled-news processing are excluded from the initial version and can be added as separately tested features later.

For forecast day d, the main target is Y[d]=1 if a new registered onset occurs in sessions d through d+9, and 0 otherwise. Forecasts during the continuation of an old episode are not credited with a new onset. The future price path may be used to establish a historical outcome; it may never enter that date's predictor row.

An onset can require later observations to confirm persistence. Therefore, the label's information interval extends through the last session needed by the labeling rubric, potentially beyond the ten-session onset window. **Training eligibility and boundary purging must use that full confirmation interval.** This prevents a subtle form of look-ahead leakage.

Use actual session indices rather than row counts in a joined table. Track label maturity separately from data availability. No incomplete future window is treated as a negative.

To relate the study to the supplied weeks, report a prespecified weekly snapshot at the first session's pre-open cutoff, alongside the daily operating evaluation. Daily rows supply more contexts, not more independent explosions. A ten-session warning for one onset can create many positive rows; keep those rows clustered in uncertainty calculations and episode evaluation.

State is the recent history represented compactly: levels, changes, persistence and trajectory. Start with a small selection of 5-, 20- and 60-session measurements. Do not assume today's reading alone captures the setup, and do not compute every possible window.

“Large” should be interpreted relative to past-observable scale, for example trailing realized volatility or a training-sample distribution of forward path sizes. The horizon and event-rarity cutoffs remain explicit design choices. Learned thresholds must come from training data only. A square-root-of-time volatility scale is a normalization convention, not proof of Gaussian prices or constant future volatility.

**5. The demand–absorption–feedback study and competing explanations**

The earlier theoretical work deserves a structured test. We will study the proposed mechanism in components and jointly, alongside a simple benchmark and competing explanations. Prediction and causal identification remain separate claims.

**5.1 The conceptual equation and its measurement contract**

The original heuristic is:

\[
\text{Explosion pressure}\sim
\frac{\text{Core demand}+\text{Options-induced demand}}{\text{Resistance}},
\]

with feedback affecting whether an initial movement reinforces itself or is damped. This is a proposed organizing model, not a calibrated probability, a derived result of the unified paper, or a claim that all explosions share this cause.

| Quantity | Meaning in the proposed mechanism | Measurement and limit |
|---|---|---|
| Core demand | Persistent signed trading motivated by an underlying decision or execution program | Estimate persistence and expected continuation from past signed-flow measurements. Trader identity, parent orders and unexecuted inventory are generally unobserved. |
| Options-induced demand | Stock-hedging demand associated with changes in option positions | Use declared delta-equivalent trade estimates and scenarios. Option premium volume alone is not hedge shares. Counterparty/inventory signs remain uncertain. |
| Resistance | The market's ability to absorb additional directional trading | Measure spreads, displayed depth and past price-response associations separately. Larger measured impact suggests lower resistance, not a larger denominator. A chart resistance level is a different concept. |
| Feedback | Trading or liquidity changes triggered by the price/activity response | Test gamma-related hedging and alternative reinforcing/opposing channels. Do not treat all reactive trading as upward reinforcement. |

For mathematical clarity, consider our own local illustration:

\[
\Delta P=\lambda\left(Q_{\mathrm{core}}+Q_{\mathrm{opt,new}}+g\,\Delta P\right),
\qquad
\Delta P=\frac{\lambda(Q_{\mathrm{core}}+Q_{\mathrm{opt,new}})}{1-\lambda g}.
\]

Here the two Q quantities are signed share-equivalent pressures over one specified interval, lambda is a dollars-per-share impact coefficient, and g is additional signed hedge/reaction shares per dollar of price movement. If R=1/lambda, then R and g have the same units and the denominator can be written R−g. Resistance and impact therefore move in opposite directions in this simplified parameterization.

This is a local, constant-coefficient approximation. A simple repeated-feedback interpretation requires |lambda g|<1. A denominator near zero indicates extreme sensitivity and failure risk of the approximation; it is not a literal forecast of infinite price movement. Market depth, inventory, expectations and trading behavior change as price changes.

The Q decomposition is conceptual. Observed total stock flow already includes executed option hedges, and an observed impact coefficient may already incorporate feedback. We will not add inferred hedge shares to total observed stock flow or multiply an already-amplified impact estimate by another feedback factor. Predictive interactions can be tested without claiming those latent components have been structurally identified.

**5.2 What the unified paper supplies**

Muhle-Karbe, Ouazzani Chahdi, Rosenbaum and Szymanski separate persistent core orders from reaction flow. Under their model assumptions, a persistence parameter links signed flow, volume, impact and volatility. Their price-formation argument incorporates anticipated future flow. The paper supplies theoretical structure; it does not derive our ratio, identify dealer gamma, or validate Tesla explosion forecasts. [8]

Our proposed application is to ask whether continuing demand interacts with changing absorption before an onset. In particular, anticipated buying may already be reflected in price. We should measure recent surprises in flow, updates to a continuation forecast, and changes in price response—not just whether buying occurred.

A first-stage flow model will predict subsequent signed flow from earlier information. Historical flow-surprise features must be computed from genuinely prior/out-of-fold forecasts; fitted residuals from a model trained on the whole sample are not permissible. If a generated forecast is fed to the explosion model, the entire two-stage process must be nested inside chronological validation.

We will start with simple persistence/continuation models and observed response measurements. A later study may reproduce the paper's estimators and scaling checks. A full Hawkes or mixed-fractional fit is justified only after data quality, identification, timestamp sensitivity and incremental value are assessed. The paper's theoretical persistence parameter is not a ready-made daily explosion indicator.

**5.3 Institutional buying: two different hypotheses**

- **Execution persistence:** an investor divides a large decision into smaller trades. We test whether recent flow patterns predict continued same-direction trading, its intensity and possible exhaustion. Without participant or parent-order identifiers, call this estimated flow persistence, not identified institutional accumulation. Research documents persistent order flow and evidence of splitting at shorter horizons; extending an identification claim to multi-day TSLA requires testing. [16]
- **Calendar-related demand:** fund liquidity needs, rebalancing and known index events may affect trading. Use correctly timestamped calendar/flow measurements, compare with ordinary periods and control for overlapping catalysts. Monthly institutional liquidity research motivates this separate hypothesis. A turn-of-month date or options expiration is not itself proof of institutional buying. [17]

Do not infer that the previously inspected May or September episodes validate either mechanism merely because their timing aligns. Distinguish predicted demand, realized future flow (an outcome), and observable signs of a program already ending. Also test the opposing case: persistent buying is absorbed successfully and no explosion follows.

**5.4 Gamma is retained explicitly; it is not synonymous with all feedback**

For a delta-hedger with signed dealer-book gamma Gamma_D, holding volatility, time and option positions fixed:

\[
\Delta H_{\mathrm{stock}}\approx-\Gamma_D\,\Delta S.
\]

This is the local hedge adjustment, with contract multipliers included consistently. Negative dealer gamma implies buying into rises and selling into falls under this hedging behavior; positive dealer gamma implies the opposing adjustment. Timing, hedging completeness and liquidity determine how much price impact actually follows. It does not mean negative gamma alone predicts an upward move.

Gamma hedging is a concrete feedback channel. Momentum strategies, short-covering/margin mechanisms and liquidity withdrawal can also reinforce movements; some reactions instead provide stabilizing liquidity. We have no verified decomposition establishing that most Tesla feedback is caused by gamma. Short-squeeze models demonstrate another possible feedback route without proving its importance in these episodes. [19]

The Gamma Fragility research specifically motivates testing gamma imbalance together with illiquidity, with evidence at intraday horizons. We will test that interaction's additional value for our multi-day onset target. A published GEX number is an inventory-model proxy, not a direct observation of the true dealer book. [18]

Separate (a) hedge demand from new option positions, (b) gamma-driven rehedging after spot changes, and (c) delta changes associated with volatility/time. If later modeling (c), state the vanna/charm conventions and inputs. Do not label every option-related hedge as gamma feedback. Gamma concentration, signed inventory assumptions and price-relative strike/expiry structure must remain distinguishable in the dataset.

**5.5 Testable sequence**

| Hypothesis | Prespecified test | Interpretation of failure |
|---|---|---|
| H1: the demand state persists | Forecast subsequent signed flow against simple persistence and past-flow baselines | Our demand measurement does not establish useful continuation information. |
| H2: absorption is weakening | Test whether past spread/depth/impact changes improve forecasts of later price response beyond flow, price and volatility controls | The measured resistance state is uninformative or redundant; do not infer that liquidity never matters. |
| H3: gamma modifies the response | Compare gamma × liquidity and gamma × pressure effects against the same models without those interactions | The measured gamma information has not earned predictive weight for this horizon. |
| H4: the joint state anticipates explosions | Compare pre-onset predictions and false alerts for the joint mechanism with the strongest baseline and competing explanations | Mechanistic plausibility has not translated into useful onset prediction. |
| H5: transitions differ from continued rallies | Evaluate the same signal before onset, during continuation and in failed setups separately | A signal appearing only after onset belongs to detection/continuation, not advance warning. |

Passing H1–H3 does not establish H4. Failing to predict signed direction may still leave a volatility relationship, which must be reported as a narrower result. None of these predictive tests alone measures the causal percentage of a rally attributable to gamma or institutions.

**5.6 Competing explanations**

| Candidate family | Initial measurements | Main competing explanation or limit |
|---|---|---|
| Price/volume structure | Recent returns, acceleration, distance to prior range/high, trend consistency, relative volume, volatility/range compression | Ordinary momentum or volatility may explain much of the apparent setup. Compression need not break upward. |
| Market context | SPY/QQQ direction, TSLA relative strength, VIX level/change | Tesla may be participating in a broad risk-on move rather than a unique internal transition. |
| Known catalysts | Publicly announced earnings/product dates, macro releases, event proximity; later timestamped announcement features | A scheduled event predicts an opportunity for surprise, not its outcome. Unannounced news may remain unpredictable. |
| Options pricing and new-position pressure | IV, term structure, skew, OI/volume and estimated signed delta-equivalent activity | They may add information, or merely re-express price, volatility and event risk. Implied probabilities are not automatically real-world probabilities. |
| Gamma-related feedback | Signed dealer-gamma scenarios, gamma concentration by strike/expiry, spot-relative levels, state trajectory and liquidity interactions | Actual dealer inventory is uncertain. Gamma hedging may amplify or damp a move; it does not independently establish its direction or timing. |
| Stock flow/liquidity | Estimated signed trade flow, its persistence/change, spread, top-of-book depth, quote imbalance, price-impact associations | Flow can be reactive or anticipated. Observed depth is incomplete; contemporaneous impact is not advance prediction. |
| Other positioning or attention | Published short interest, borrowing constraints, independently timestamped fund-flow/news/attention data if accessible | Publication lags, coverage, cost and ambiguous interpretation may outweigh benefit. Daily short-sale volume is not outstanding short interest. [6] |

Build the modest daily-data benchmark and the mechanism specification together. The options/gamma and microstructure pilots are planned research stages with explicit tests, rather than an unrestricted search for interesting features. Their measurements receive the same chronological evaluation as alternatives. Expand costly datasets only after the small pilot establishes feasibility. Failure of a poor proxy rejects that measurement, not every conceivable version of a mechanism.

No initial requirement for Hawkes models, a scalar “stored energy” variable, a universal explosion equation, reinforcement learning or a deep sequence model. If a simpler model works, keep it. If only susceptibility is predictable and exact ignition is not, say so.

**6. Concrete data plan**

| Stage | Source and fields | Reason |
|---|---|---|
| First | Alpaca historical TSLA/SPY/QQQ daily OHLCV with corporate-action handling; Cboe daily VIX | Build the event registry and a broad, inexpensive benchmark. Alpaca's older SIP-history access is documented; Cboe publishes daily VIX history. [2, 5] |
| First | Official company and macro/exchange calendars with announcement/release timestamps | Separate known catalyst proximity from surprise. Do not use today's revised calendar as if it were known historically. |
| Options/gamma pilot | ThetaData historical chains: bid/ask, strike, expiry, OI, IV, delta and gamma | Rebuild a consistent series; keep options-pricing features, gamma magnitudes and signed dealer-inventory scenarios separate. Test the gamma–liquidity interaction explicitly. |
| Options expansion | ThetaData trades paired with quotes, classification coverage and multi-leg flags | Investigate signed option activity only if the sample can support it reliably. |
| Microstructure pilot | Alpaca TSLA SIP trade prints and quotes, aggregated into one-/five-minute measurements | Build the demand-continuation, flow-surprise and absorption measurements needed for H1–H4. Retain measurement uncertainty. |
| Institutional-cycle context | Official index/rebalance/expiry calendars and fund-flow publications where accessible | Store publication lags and distinguish calendar opportunity from measured TSLA-specific buying. No institutional-identity claim from public prints. |
| Optional later | Cboe C1 transaction classifications | Calibrate covered participant/trade-sign assumptions; not a market-wide dealer inventory census. [7] |

Seek daily history from 2016 onward and the longest usable common history for family comparisons. Vendor coverage is not assumed to be complete. Daily event/benchmark data can have a longer history than tick or options experiments, but model comparisons use matched dates.

Alpaca requires explicit `feed=sip` for consolidated historical selection; its FAQ permits queries ending at least 15 minutes ago without the recent SIP subscription. Verify the user's account and historical endpoint behavior before relying on free access or a bulk download. [2]

For an options pilot needing gamma and trade Greeks, prefer **ThetaData Pro at the currently posted $160/month individual price**, after an endpoint/sample check. Standard is $80/month but has fewer Greek endpoints. This is a convenience choice to reduce initial implementation, not a claim of superior inference. A running Theta Terminal is required. [3]

Download a small, diverse sample first. Include ordinary sessions, earnings, a corporate-action boundary, the missing 2024 region and both sides of the documented November 2025 quote-unit change. Use it for measurement engineering, not picking profitable thresholds. Benchmark runtime/storage before multi-year tick collection. Download complete date partitions, not only rally examples. Do not initially download every option quote for every contract across a decade.

Public GEX/DIX data are optional replication inputs with their own definitions and availability limits. Rebuild one consistent options history if testing the GEX hypothesis. Do not splice a new vendor's reconstruction into a revised public series or interpolate missing gamma dates.

**7. Data quality and measurement rules**

The pipeline is raw records → validated session data → versioned features/outcomes → frozen experiment → predictions → evaluation report. Every stage has reproducible inputs and explicit eligibility rules.

Store observation time, availability/release time when known, retrieval time, session, provider, units, raw-file reference, transform version and quality flags. Preserve revisions and original forecast inputs. A conservative lag can address uncertain release timing; it cannot undo retrospective data revisions. Prospective snapshots provide the cleanest availability record.

Required checks:

- Complete exchange calendar, holidays/early closes and daylight saving; no shortened windows after missing-data joins.
- Corporate actions and option multipliers/strikes aligned to the price basis. Never mix adjusted stock prices with incompatible raw option inputs.
- Pagination, duplicates/corrections, trade/quote alignment, stale/crossed quotes, quote conditions and classification coverage.
- Open-interest publication timing, incomplete options chains and actual field availability at 09:00.
- Independent spot/daily-total checks on the sample, and investigation of material discrepancies.
- Missing fields remain missing, not zero. Critical gaps exclude a feature row or trigger a validated fallback.
- Deterministic reproduction from frozen inputs, and injected missing/future data to test failure behavior.

Alpaca documents changing quote-size display from round lots to shares on November 3, 2025. Verify how the actual historical endpoint represents both periods before applying a conversion; otherwise an artificial liquidity break can become a model feature. [4]

For microstructure, distinguish estimated signed executed volume from quote-based order-flow imbalance. Keep ambiguous trades unclassified. Neither identifies institutions or autonomous demand. Estimate rolling price-response slopes over many intervals; do not use daily return divided by almost-zero net flow. Top-of-book data do not establish all hidden liquidity or full-book replenishment.

For options, distinguish observed transactions, estimated signs and assumed inventory. A calls-positive/puts-negative GEX series is not actual dealer positioning. Changes can reflect spot, time, volatility and expiration, not new buying. Test plausible conventions and discard confident directional interpretation when assumptions reverse it. Dealer stock hedges may already appear in the equity tape; do not add hypothetical hedging to observed flow and double-count it.

Order-flow research motivates hypotheses, but persistent flow can coexist with limited return predictability, and short-interval impact relations do not establish ten-session forecasting. [8]

**8. Initial analysis and model choices**

Begin with an event table and simple descriptive tests, not automatic model search. Compare pre-onset conditions with all eligible non-event contexts, including failed setups. Inspect whether the apparent signal occurs before onset or only afterward, whether it is dominated by known catalysts, and whether the result is stable across definitions. Do not label unreviewed weeks as negatives.

Then fit a small hierarchy:

| Model | Role |
|---|---|
| Historical event frequency | Necessary probability benchmark. Estimate on the training period only. |
| Simple price/market/calendar rule and regularized logistic regression | Tests whether basic information already captures the useful signal. |
| Small Explainable Boosting Machine | Preferred nonlinear challenger: readable feature effects and a few selected interactions. |
| Shallow, strongly regularized LightGBM | One more flexible challenger, used only if sample size and chronological evaluation justify its complexity. |

Start with roughly 8–12 nonredundant baseline predictors and a few representatives per added family. Choose exact formulas before performance evaluation. Sample size and independent positive episodes govern complexity; millions of ticks do not create millions of independent training events. EBM can express specified higher-order interactions, but do not search every triple. [9]

Use the same learner and tuning budget for matched-date comparisons. Define B as price/market/known-catalyst controls, F as demand/absorption measurements, O as options pricing/new-position pressure, and G as separately declared gamma/hedging proxies. Initial comparisons are B, B+F, B+O, B+G and B+F+O+G, followed by removing G from the combined model and removing the prespecified gamma interactions while retaining the main effects. Also compare levels alone with the fixed level-plus-trajectory dictionary. Calendar/institutional-flow extensions get their own logged comparison. Keep dates, labels and exclusions identical; fit all generated F/G features inside the training boundary. Separate data-coverage differences from predictive differences.

Estimate whether gamma improves held-out forecasts conditional on the other information, and whether adding non-gamma information to a gamma model improves them further. This can establish comparative predictive contribution; correlated proxies and unobserved inventory prevent interpreting ablation scores as percentages of causation. Report sensitivity to dealer-sign assumptions and observations where the sign is indeterminate.

Tune against a proper probability score, initially chronological validation log loss. Also report Brier score and calibration. Do not select on training accuracy or ROC-AUC alone. If class weighting or resampling is tested, account for the changed class prevalence before presenting probabilities; default to natural prevalence. Calibration must use chronological predictions, not the fitting rows. Avoid flexible calibration curves unsupported by the scarce event count. [10]

Interpret model explanations as associations. Held-out removal of a whole feature family is stronger evidence of incremental information than one importance plot. No single feature, model or theoretical mechanism is required to win.

Supporting return/path models are secondary. If useful, use quantile regression for the ten-session ending return, maximum closing upside and maximum closing downside from the next session's open. “Finishes 10% up” and “reaches 10% up” are different outcomes; separate marginal forecasts also do not give first-hit or joint probabilities. Do not let an improvement in these supporting tasks stand in for successful explosion prediction.

**9. Evaluation and the definition of useful**

Primary operational report: **unique onsets detected, unique false alerts, precision, episode recall and warning lead time**, compared with the strongest baseline under the same alert policy. Probability quality is also mandatory. The model must answer both “did it catch the episodes?” and “how often did it cry wolf?”

Use a declared comparison budget of approximately four distinct alerts per year, with eight per year as a secondary tradeoff. These are initial research operating points, not promised alert rates or claims about the natural event frequency. Select the score cutoff from chronological validation predictions and freeze it in the outer test period. Do not choose the best four alerts after seeing a test year's outcomes. Actual out-of-sample alert frequency can differ.

Cluster daily alerts into one alert episode using a fixed ten-session cooldown for the first operating rule. Match at most one alert to one onset within the warning window. Report pre-onset lead-time bins and same-session pre-open warnings separately. Alerts after onset are continuation observations. Unmatched alerts count as false only after their complete outcome/confirmation windows mature and the outcome review is complete.

Validate chronologically: an initial eligible training history of about three years, followed by successive six-month outer evaluation blocks. Tune in earlier chronological folds only. For sparse-event folds, report counts and uncertainty explicitly; a zero-event block still measures alert burden but cannot estimate event recall. No random train/test split.

Purge training labels whose entire outcome/confirmation intervals reach the validation/test boundary. Purging must include the event rubric's forward confirmation, not just a nominal ten-day return. Fit feature selection, normalizers, thresholds, calibration and hyperparameters inside training/validation only. Keep related event episodes together in robustness tests.

Use dependence-preserving block/episode uncertainty estimates and sensitivity to block length. Adjacent correct dates around one rally are not independent successes. Preserve market regimes and serial dependence in any placebo procedure; arbitrary label shuffles or circular shifts do not automatically constitute valid null tests in a changing market.

The known 2024/2025 examples and inspected 2026 conditions already influenced the project. Leaving one out of a new fit does not erase that exposure. Call those tests retrospective chronological evaluation or episode robustness. The strongest confirmation is a **prospective ledger after freezing the protocol**. A historical holdout is genuinely untouched only if neither its outcomes nor its results influenced design; do not invent one by renaming dates.

Log every attempted model/specification, including failures. Limit the first search to a small declared configuration grid. Repeatedly choosing features from outer-test feedback turns those periods into development data. Multiplicity control and sensitivity reporting must reflect the actual search, not just the winning model. A language model may know historical episodes from pretraining; prospective testing matters even when its file access is restricted.

Promotion requires better event precision/recall tradeoffs than the baseline, reasonable probability calibration, positive evidence across more than one period, and robustness to plausible label/data assumptions. Report confidence intervals, not a universal performance promise. If evidence is too sparse, retain the model as experimental rather than invent an event-count threshold that guarantees validity.

**10. What findings would change our mind**

| Finding | Decision |
|---|---|
| Consistent explosion labels cannot be produced | Resolve the target ambiguity before training a claimed explosion predictor. |
| Basic price/market/calendar information matches richer models | Keep the simpler model; do not pay for complexity without benefit. |
| One GEX proxy adds no stable held-out value | Exclude that proxy from production; retain the distinction between proxy failure and rejection of gamma hedging as a mechanism. Test only the preregistered alternative inventory scenarios, not unlimited replacements. |
| Properly measured flow/gamma interactions add no repeatable value | Report no demonstrated incremental value for this target/horizon and use the simpler predictor; preserve the failed test in the research record. |
| A feature works only after the episode begins | Reclassify it as continuation/detection information, not advance onset prediction. |
| Models predict broad volatility but not upward episodes | Report that narrower result; the main objective remains unmet. |
| Apparent results depend on revised data, one catalyst episode or a convenient inventory convention | Withhold predictive claims and repair/retest. |
| No candidate improves over baseline with useful alert precision | Conclude that the tested data/design do not establish reliable advance prediction. |
| A frozen model performs well prospectively | Proceed to a separate execution study, without claiming a proven causal mechanism. |

Different explosions may arise through different routes. Do not force every event into one universal causal story. Initially report subgroups; build a mixture of specialized models only after enough independently labeled episodes justify it.

**11. The front end, back end and why**

**Final version-1 stack recommendation: Streamlit + a Python research package and persistent worker + Parquet/DuckDB + SQLite, on one DigitalOcean Ubuntu Droplet.**

| Component | Responsibility |
|---|---|
| Streamlit browser interface | Data status, episode review, saved experiment controls, results and forecasts. A Python app directly serves browser users. [11] |
| Python research package | Provider adapters, features, labels, splits, statistical models, evaluation and report generation. |
| Separate worker process/container | Long-running ingestion and experiment jobs; does not depend on the browser session staying open. |
| SQLite job/model/forecast ledger | Durable job states, configuration hashes, model versions and original predictions. One concurrent worker initially. |
| Compressed Parquet + DuckDB | Versioned market-data partitions and local analytical queries; no separate managed database needed. |
| DigitalOcean Spaces | Durable raw/artifact storage and backups; verify restoration. |
| Docker Compose and Caddy | Reproducible services, restart policies and authenticated HTTPS access at one private address. [11, 14] |

No separate JavaScript front end or FastAPI service is required for a single private Python app initially. If a later interface or external integration needs an API, expose the existing research functions through one without rewriting the model pipeline.

This is a modest custom research app, not zero implementation. Its advantage is that the custom work directly serves our target. UI session state is not the job queue; results and jobs live in durable storage. Closing a phone browser must not terminate an experiment. A server crash may require a stage restart; do not promise arbitrary automatic continuation from memory.

Four main views: **Episodes/Data**, **Experiments**, **Evidence**, **Current Forecast**. Show false alerts as prominently as successful episodes. The forecast page displays the selected model, baseline probability, uncertainty/evidence grade, input timestamp and whether data quality permits a forecast. Do not substitute a confident AI-written narrative for measured output.

Acceptance checks: open on a phone, launch a saved experiment, close and reopen the browser, recover the job/report; test a failed worker, duplicate submission, missing input and backup restore. Measure usability before calling the app seamless.

**12. Microsoft and Google have bounded roles**

Qlib and RD-Agent are useful research infrastructure, not a hosted Microsoft explosion-prediction API. Qlib's stock-ranking conventions and RD-Agent's financial workflow need adaptation for our single-stock rare-event task. The native RD-Agent web UI supplies traces/process controls, but it does not supply our event registry, scorer or product views. [12]

Therefore neither Qlib nor Microsoft's interface is a mandatory foundation for version 1. Reuse Qlib components only when they demonstrably reduce work. Once the fixed pipeline works, RD-Agent can propose and implement candidate features/model changes against our evaluator. It must not choose what “explosion” means or rewrite the test to make itself look successful.

Initial automation limit: at most ten candidate changes per research cycle, plus a hard compute/model-call budget. The trusted evaluator owns dates, labels, scoring and exclusion rules. Generated-code workers have only allowed training data, no final-test access, no host secrets or Docker socket, and bounded resources. Keep the evaluator outside agent-writable paths. These protections require engineering; they are not automatically guaranteed by installing RD-Agent.

Google Co-Scientist/Hypothesis Generation and Computational Discovery can supply competing ideas or critique if access becomes available. Current Google Labs offers interest routes; no verified public integration is needed for this build. Do not delay research waiting for access or confuse an ordinary Gemini API call with those products. [13]

Floot is not a dependency in the initial setup. If later chosen for interface polish, it can connect to the same worker/API. The research logic and dataset remain portable.

My role is to choose and criticize hypotheses, audit sources/labels, implement the deterministic pipeline, interpret failures and maintain the experiment record. The fitted model produces numerical probabilities. You operate saved research workflows and review concrete reports; you do not have to manually engineer each experiment or settle every statistical choice.

**13. Build sequence and evidence gates**

| Milestone | Deliverable | Gate before the next stage |
|---|---|---|
| 1. Outcome and theory specification | Clean example paths, price-only annotation rubric/episode registry, H1–H5 register and measurement contracts | Outcome labels are independent of the proposed predictors; each theoretical claim has a measurable test and failure interpretation. |
| 2. Daily data/benchmark | Versioned daily dataset, baseline model, chronological evaluator and first report | Calendar/availability checks pass; report reproduces from one saved configuration. |
| 3. Mechanism and competing-data pilots | Options/gamma and flow samples, institutional-calendar availability, cost/runtime estimates and explicit feature dictionaries | The quantities for H1–H3 are reproducible, distinguish observations from inference and are available at the forecast cutoff. |
| 4. Mechanism and onset tests | H1–H5 results, matched-date family/interaction removals, and onset/false-alert reports | State persistence and gamma interactions are tested explicitly; predictive improvements do not become causal claims. |
| 5. Self-service app | Private Streamlit app, saved jobs/reports, schedules and backups | Browser-close, failure recovery and restore checks pass. |
| 6. Bounded research automation | RD-Agent adapter if useful, experiment budget and protected evaluator | Agent-generated changes cannot alter the target or leak evaluation data. |
| 7. Prospective testing | Immutable forecast ledger and matured outcome reports | Enough independent evidence accumulates; weak evidence stays experimental. |
| 8. Execution study if earned | Cost-aware stock strategy specification and paper test | Predictive and execution evidence are evaluated separately. |

Basic UI work can accompany the benchmark, but design polish and research agents do not delay the first evidence report. No paid multi-year tick collection before the sample/throughput gate. No arbitrary implementation deadline before seeing actual provider access and data quality.

Daily operation: ingest completed-session data, validate, freeze the 09:00 feature snapshot, issue/save the approved forecast, then score it only after the complete label-confirmation interval matures. Missing inputs cause a labeled validated fallback or no forecast. Retain the original predictions. Monitor freshness, coverage, probability calibration and false-alert burden.

Model refits follow a registered monthly schedule using only matured labels; they do not automatically redesign features. New design decisions start a new logged research/prospective period. An initial 60 trading sessions can test operations but cannot establish rare-event forecasting accuracy by itself.

**14. Cost and scope**

Current listed starting prices, checked 7 October 2026:

- DigitalOcean Basic 4 vCPU, 8 GiB RAM, 160 GiB disk: **$48/month**.
- DigitalOcean Spaces: **$5/month** starting plan, including 250 GiB storage and 1 TiB outbound transfer, with overages additional. [15]
- Older Alpaca SIP history: documented no-subscription route for suitably delayed historical queries, subject to account verification. [2]
- ThetaData Options Pro when the options pilot is justified: **$160/month** individual pricing; confirm applicable usage terms and endpoint access. [3]
- Model API calls, taxes, domain, snapshot backups, storage/transfer overages and optional special datasets: separate.

Planning subtotal: about **$53/month for the initial infrastructure**, about **$213/month with Options Pro**, before the additional items. The 8 GiB server is a starting estimate for one worker, not a guarantee for large tick jobs. Stream downloads and aggregate in batches; measure before increasing resources. The initial data budget has no automatic Cboe, paid news or borrowing-data purchase.

No server, subscription, order or external project was created in this blueprint review. This is a private research app. If it later becomes a commercial or shared data product, provider permissions need a separate check.

A profitable execution rule is a later project: define trade timing, costs, spread/slippage, overnight gaps, sizing, overlapping signals, exits and benchmarks. A forecast of maximum upside is not an achievable fill. Options trading requires its own contract, IV, spread and expiry analysis. The first release has no live-trading permissions.

**15. What we commit to now**

Commit to the user's event-prediction goal; a price-only event-definition study; an explicit demand–absorption–feedback investigation anchored in the unified paper; separate institutional-execution and calendar hypotheses; a gamma-hedging study; competing explanations; simple models before complex ones; chronological evaluation; prospective confirmation; and one small self-service app.

We commit to testing gamma, not to making a GEX proxy succeed. We commit to examining persistent demand, not to labeling public prints as known institutional orders. The theory guides measurements and prespecified interactions; the results determine whether they belong in the operational predictor. Microsoft's platform is adopted only where it reduces actual work.

The first concrete result should be an auditable episode dataset, a registered mechanism study and a baseline report answering: **what counts as one of these explosions, what would our theory predict before it, and can those predictions distinguish explosions from failed setups?**

**Sources and scope of support**

1. Half on a Double: [methodology](https://halfonadouble.com/methodology), [data](https://halfonadouble.com/data), [series metadata](https://halfonadouble.com/api/v1/series.json). Model convention, historical replacement and availability limitations.
2. Alpaca: [Market Data FAQ](https://docs.alpaca.markets/us/docs/market-data-faq). Historical SIP access and feed distinction.
3. ThetaData: [pricing](https://www.thetadata.net/pricing), [subscription matrix](https://www.thetadata.net/docs/Articles/Getting-Started/Subscriptions.html). Current costs, Greek endpoints and Terminal requirement.
4. Alpaca: [quote-size change](https://docs.alpaca.markets/us/v1.1/changelog/marketdata-bid-and-ask-size-display-change).
5. Cboe: [VIX history](https://www.cboe.com/tradable-products/vix/vix-historical-data).
6. FINRA: [Short Interest—What It Is, What It Is Not](https://syndication.finra.org/content/short-interest-what-it-what-it-not).
7. Cboe: [Enhanced US Options Trade-by-Trade Execution Detail](https://datashop.cboe.com/enhanced-us-options-trade-by-trade-execution-detail).
8. Muhle-Karbe et al.: [A unified theory of order flow, market impact, and volatility](https://arxiv.org/html/2601.23172v2); Cont, Kukanov and Stoikov: [The Price Impact of Order Book Events](https://arxiv.org/pdf/1011.6402). Mechanistic motivation, not validation of this forecasting target.
9. InterpretML: [custom interactions](https://interpret.ml/docs/python/examples/custom-interactions.html); LightGBM: [parameters/objectives](https://lightgbm.readthedocs.io/en/stable/Parameters.html).
10. Scikit-learn: [probability calibration](https://scikit-learn.org/stable/modules/calibration.html).
11. Streamlit: [architecture](https://docs.streamlit.io/develop/concepts/architecture/architecture), [Docker deployment](https://docs.streamlit.io/deploy/tutorials/docker).
12. Microsoft: [Qlib](https://github.com/microsoft/qlib), [RD-Agent](https://github.com/microsoft/RD-Agent), [quant scenario](https://rdagent.readthedocs.io/en/latest/scens/quant_agent_fin.html), [UI](https://rdagent.readthedocs.io/en/latest/ui.html).
13. Google: [Science experiments and access routes](https://labs.google/science/).
14. Caddy: [automatic HTTPS](https://caddyserver.com/docs/automatic-https).
15. DigitalOcean: [Droplets](https://www.digitalocean.com/pricing/droplets), [Spaces](https://www.digitalocean.com/pricing/spaces-object-storage).
16. Tóth, Palit, Lillo and Farmer: [Why is order flow so persistent?](https://arxiv.org/abs/1108.1632). Persistence and the splitting/herding distinction, with the paper's timescale limits.
17. [Dash for Cash: Monthly Market Impact of Institutional Liquidity Needs](https://academic.oup.com/rfs/article/33/1/75/5494694). Separate motivation for institutional calendar-related liquidity flows.
18. Barbon and Buraschi: [Gamma Fragility](https://abarbon.com/papers/gamma-fragility). Gamma-imbalance and illiquidity interaction; intraday empirical scope.
19. Feinstein: [Clearing prices under margin calls and the short squeeze](https://arxiv.org/abs/2102.02176). A theoretical non-gamma feedback mechanism, not evidence identifying the cause of the supplied TSLA episodes.

The sources verify capabilities and constraints. The research sequence, targets, model choices, operating points and architecture are my recommendations; the cited sources do not establish that this project will predict explosions successfully.
