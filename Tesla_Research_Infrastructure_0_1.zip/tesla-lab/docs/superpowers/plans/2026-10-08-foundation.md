# Tesla Infrastructure Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans inline, then one independent whole-branch review.

**Goal:** Build the runnable research foundation in the approved blueprint.
**Architecture:** Streamlit and persistent worker share a SQLite ledger and immutable Parquet objects. A trusted Python evaluator reads pinned dataset/annotation versions and writes reproducible reports.
**Tech Stack:** Python 3.12, Streamlit, pandas, PyArrow, DuckDB, scikit-learn, exchange-calendars, Docker Compose, Caddy.
**Spec:** ../specs/2026-10-08-foundation-design.md

## Global Constraints
- Python 3.12; one active worker; 09:00 America/New_York cutoff.
- Raw/data/report objects immutable; job claims fenced by lease tokens.
- Unknown historical availability remains retrospective. No live promotion automatically.
- 10-session onset horizon and cooldown, 3-year training, six-month tests.
- Reviewed intervals and full confirmation maturation required for outcomes.
- No credentials in source or saved bundles; existing DigitalOcean server unchanged.

## Review Focus
- Abandoned workers cannot overwrite results after another claim.
- Missing exchange sessions cannot shorten feature/label windows.
- Unknown label coverage cannot silently supply negatives.
- Invalid/tampered archives and uploaded paths cannot escape data storage.
- Private app is never published without authentication.

### Task 1: Data and job foundation
**Files:** src/tesla_lab/{config,ledger,data,calendar}.py; tests/test_foundation.py; pyproject.toml.
**Interfaces:** Ledger(root) initializes SQLite; enqueue(kind,payload) -> id; claim(worker) -> job; finish(id,token,status,result). Lake(ledger).put(kind,frame,metadata) -> dataset_id; read(dataset_id) -> frame.
- [ ] Write and run failing tests for duplicate jobs, concurrent claims, expired-token rejection, stale recovery, immutable dataset versions, unsafe clocks and invalid exchange dates.
- [ ] Implement transaction/lease fencing, typed metadata, content identities and dataset validation.
- [ ] Run full pytest suite; commit a green foundation.

### Task 2: Ingestion, episode registry and backup
**Files:** src/tesla_lab/{providers,episodes,backup,worker}.py; tests/test_ingestion.py.
**Interfaces:** import_audit(ledger,archive) -> dataset IDs; Alpaca.fetch_daily(symbols,start,end) -> frame; save_review(ledger,review) -> immutable id; backup(root,path); restore(path,target). Worker executes allowlisted jobs with heartbeats.
- [ ] Write and run failing tests for audit provenance/quarantine, paginated provider responses, future availability, unreviewed negatives, bad session annotations, atomic backup restore and path traversal.
- [ ] Implement provider, schema layers, annotation snapshots, worker job dispatch and backups.
- [ ] Run full pytest suite; commit.

### Task 3: Frozen benchmark and research views
**Files:** src/tesla_lab/{research,ui,cli}.py; app.py; tests/test_research.py; tests/test_app.py.
**Interfaces:** run_experiment(ledger,config) -> report path; build_features(frame) -> calendar-aligned features; labels(sessions,review,horizon) -> known outcomes with interval ends. UI pins versions and queues jobs.
- [ ] Write and run failing tests for chronological feature construction, confirmation purging, mature-only review coverage, blocked missing labels and a full synthetic report through worker.
- [ ] Implement fixed inner/outer folds, probability/event scoring, persisted configuration and reports.
- [ ] Write failing four-view/restart tests; implement app and command line.
- [ ] Run full pytest suite; commit.

### Task 4: Deployable release
**Files:** Dockerfile; compose.yaml; deploy/Caddyfile; deploy/setup.sh; README.md; .env.example; requirements.lock; tests/test_deployment.py.
**Interfaces:** local loopback app launch; authenticated Caddy public profile; durable named volume; backup scheduler with Spaces optional.
- [ ] Verify compose structure, non-root/restricted services, environment split and fail-closed auth config.
- [ ] Run meaningful recovery tests, app simulation, HTTP health check, independent code review and one fix pass.
- [ ] Import real audit into local initialized store, retain no falsely reviewed negatives. Package code/data bootstrap with hashes and persist archive.
- [ ] Report built vs tested vs hosted distinctly.
