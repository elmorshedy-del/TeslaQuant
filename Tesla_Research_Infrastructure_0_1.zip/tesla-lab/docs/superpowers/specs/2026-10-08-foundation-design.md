# Tesla research infrastructure

Implements the approved research-blueprint.md, sections 7–13. Ahmed requested implementation after reviewing the architecture; proceed inline without requesting another design approval.

## Scope
A portable, private, single-user Streamlit research application with a separate persistent worker. This release establishes data ingestion, immutable versions, an episode review registry, a frozen baseline experiment, reports and original forecast records. It does not certify an explosion rubric, infer institutional identities, buy vendor subscriptions or install autonomous code agents.

## Components and contracts
- Python 3.12. Streamlit interface; one worker. SQLite ledger with WAL, transactional claims, heartbeats and stale-job recovery. Browser sessions do not own jobs.
- Immutable content-addressed Parquet versions queried with DuckDB; manifests in SQLite. Raw responses/archive bytes have SHA-256 identities. All joins retain the exchange calendar.
- Dataset contracts: equity_daily, gamma_daily, flow_daily, option_chain, calendar_events. Records carry observation, availability and retrieval clocks. Unknown historical availability is explicitly retrospective and cannot authorize a live forecast. Units and inventory conventions are metadata.
- Daily provider: Alpaca consolidated history with pagination, adjustment=split, feed=sip. Credentials are environment-only. Uploaded audit data retain retrospective status and original provenance. Gamma from the prior audit is stored separately with quarantine markers; never combined with split-adjusted option strikes automatically.
- Review registry uses append-only versions. Reference weeks stay unconfirmed. An annotation snapshot specifies complete reviewed intervals, confirmed onset/confirmation dates and rubric version. Unreviewed dates cannot become negative training examples.
- Fixed daily benchmark: prior-session return, volatility, relative volume, distance to rolling high, and relative-market returns. No gamma-only rule is silently substituted. Gamma/flow schemas are ready for later measured feature families.
- Prediction cutoff 09:00 America/New_York; 10 actual trading-session target; 5 secondary. Labels whose full forward/confirmation interval reaches a fold boundary are purged. Three-year initial training; six-month outer blocks with inner chronological validation. Fit transformations only in training. Reports include log loss, Brier, unique alert counts, recall, precision and session lead time, with 10-session cooldown.
- Insufficient classes/history, incomplete labels, unsupported input state or stale data produces a blocked experiment/forecast with a readable reason. Retrospective reports never become live forecasts.
- Forecast ledger is append-only. No model is promoted automatically from an experiment. This release deliberately has no production model promotion path until prospective protocol is frozen.
- Backups take a consistent SQLite snapshot, include immutable data/report objects, verify SHA-256 on restoration and reject unsafe archive paths. Spaces upload is optional and credentials live only in the worker.
- Docker Compose: app, worker, backup scheduler, Caddy. Only Caddy publishes ports; authentication required for public access. Local launch binds loopback. Runs as non-root, with bounded memory/CPU and restart policies. No Docker socket is mounted.

## Interface
Four views: Episodes / Data, Experiments, Evidence, Current Forecast. Data version and evidence status always visible. Audit imports are a worker job; uploaded files are bounded. Episode review validates real exchange sessions and records complete review separately from supplied example weeks. Experiment forms pin dataset and annotation versions. Reports preserve config/source versions and allow download. Forecast view explicitly blocks until a frozen eligible model exists.

## Acceptance
Prove immutable versions and query reproducibility; duplicate job suppression; concurrent single claims; stale lease recovery; failed job isolation; future observations rejected; incomplete calendars and unknown review dates excluded; labels purged through confirmation; reports persist across app restarts; backup restore and tamper rejection; four app views work using Streamlit AppTest. Run a synthetic full pipeline only in tests and label it synthetic. Import the existing real audit without assigning false negative labels.

## Deployment boundary
Build and verify here, then prepare a tested deployment bundle. Existing DigitalOcean resources remain unchanged. A new server can be provisioned after deployable code is available; the current account's small server is not silently reused. Lack of a supported remote shell/deployment path is reported explicitly rather than claiming hosting.
